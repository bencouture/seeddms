<?php
include "inc.ClassAcl.php";

$acl = new SeedDMS_Acl('lafjkl');
print_r($acl);
